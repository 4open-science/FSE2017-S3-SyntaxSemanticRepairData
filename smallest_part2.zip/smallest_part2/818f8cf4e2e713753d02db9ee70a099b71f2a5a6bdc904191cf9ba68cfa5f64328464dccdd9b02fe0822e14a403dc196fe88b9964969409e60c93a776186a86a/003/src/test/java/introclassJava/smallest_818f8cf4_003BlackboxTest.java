package introclassJava;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class smallest_818f8cf4_003BlackboxTest {

    @Test(timeout = 1000) public void test1 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("1 2 3 4");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
    }
    @Test(timeout = 1000) public void test2 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("4 3 2 1");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 1);
    }
    @Test(timeout = 1000) public void test3 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 4 2 1");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 1);
    }
    @Test(timeout = 1000) public void test4 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 2 4 1");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 1);
    }
    @Test(timeout = 1000) public void test5 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("1 1 1 1");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 1);
    }
    @Test(timeout = 1000) public void test6 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > 2 is the smallest";
        mainClass.scanner = new java.util.Scanner ("2 2 2 3");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 2);
    }
    @Test(timeout = 1000) public void test7 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > -1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("0 0 0 -1");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == -1);
    }
    @Test(timeout = 1000) public void test8 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
            "Please enter 4 numbers separated by spaces > -1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("0 -1 0 0");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == -1);
    }

    //Additional test cases
    @org.junit.Test(timeout = 1000) public void test9 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > -16907 is the smallest";
        mainClass.scanner = new java.util.Scanner ("-11554 -7239 10330 -16907");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == -16907);
    }
    @org.junit.Test(timeout = 1000) public void test10 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 3 is the smallest";
        mainClass.scanner = new java.util.Scanner ("6 3 3 8");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 3);
    }
    @org.junit.Test(timeout = 1000) public void test11 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 1 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 1 3 2");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 1);
    }
    @org.junit.Test(timeout = 1000) public void test12 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 3 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 4 3 8");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 3);
    }

    @org.junit.Test(timeout = 1000) public void test13 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 3 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 3 4 8");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 3);
    }

    @org.junit.Test(timeout = 1000) public void test14 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 3 is the smallest";
        mainClass.scanner = new java.util.Scanner ("7 4 3 3");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 3);
    }

    @org.junit.Test(timeout = 1000) public void test15 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 2 is the smallest";
        mainClass.scanner = new java.util.Scanner ("2 3 2 4");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 2);
    }

    @org.junit.Test(timeout = 1000) public void test16 () throws Exception {
        smallest_818f8cf4_003 mainClass = new smallest_818f8cf4_003 ();
        String expected =
                "Please enter 4 numbers separated by spaces > 2 is the smallest";
        mainClass.scanner = new java.util.Scanner ("3 2 2 4");
        mainClass.exec ();
        String out = mainClass.output.replace ("\n", " ").trim ();
        //assertEquals (expected.replace (" ", ""), out.replace (" ", ""));
        assertTrue(mainClass.outnum == 2);
    }
}

